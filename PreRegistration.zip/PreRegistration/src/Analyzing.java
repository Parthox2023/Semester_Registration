import java.util.ArrayList;
import java.util.Scanner;

public class Analyzing {
    ArrayList<String> faculties;
    ArrayList<Course> courses;
    ArrayList<Integer> selectedIndices;

    public Analyzing(ArrayList<Course> courses, ArrayList<Integer> selectedIndices) {
        this.faculties = new ArrayList<>();
        this.courses = courses;
        this.selectedIndices = selectedIndices;
    }

    public void view() {
        int theory = 0, lab = 0, match = 0;
        int[][] week = new int[2][7];
        for (int i : selectedIndices) {
            Course course = courses.get(i);
            if (courses.get(i).credits == 3) {
                faculties.add(course.title+course.faculty);
                theory++;
            } else {
                for (String s : faculties) {
                    if ((course.title.substring(0,course.title.length() - 4)+course.faculty).equals(s)) {
                        match++;
                    }
                }
                lab++;
            }
            ArrayList<Integer> dayTime = courses.get(i).dayTime;
            for (int d : dayTime) {
                int day = d/1440;
                int time = d%1440;
                if (time < week[0][day] || week[0][day] == 0) week[0][day] = time;
                if (time > week[1][day]) week[1][day] = time;
            }
        }
        int days = 0, minute = 0;
        for (int i = 0; i < week[0].length; i++) {
            if (week[0][i] != 0) days++;
            minute -= week[0][i];
            minute += week[1][i];
        }

        //add your conditions using '||' to ignore this registration variable
        if (!(lab == 2 && match == lab && minute <= 15*60 && days < 4)) return;

        System.out.print(theory + "+" + lab + "\t\t");
        System.out.print(match + "\t\t");
        System.out.print(days + "\t\t");
        System.out.print(minute/60 + ":" + minute%60 + "\t\t");
        System.out.print(selectedIndices + "\t");

        Scanner scn = new Scanner(System.in);
        System.out.print("\u001B[32m[Press y to View]\u001B[0m");
        while (scn.nextLine().equals("y")) getView();
    }

    private void getView() {
        for (int i = 8; i <= 18; i++) {
            if (i < 10) System.out.print("0");
            System.out.print(i + ":00:00    ");
        }
        System.out.println();
        for (int i = 0; i < 8; i++) {
            int spc = 12;
            int width = spc*11+1;
            for (int j = 0; j < width; j++) {
                if (j%spc == 0) System.out.print('+');
                else System.out.print('-');

            }
            System.out.println();
        }
    }
}
