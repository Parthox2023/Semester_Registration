import java.util.ArrayList;
import java.util.Arrays;

public class Course {
    String code;
    String section;
    String title;
    int credits;
    String faculty;
    int advised;
    int limit;
    ArrayList<Integer> dayTime;
    String room;
    String type;

    public Course(String code, String section, String title, int credits, String faculty, int advised,
                  int limit, ArrayList<Integer> dayTime, String room, String type) {
        this.code = code;
        this.section = section;
        this.title = title;
        this.credits = credits;
        this.faculty = faculty;
        this.advised = advised;
        this.limit = limit;
        this.dayTime = dayTime;
        this.room = room;
        this.type = type;
    }

    public void getString(int i) {
        System.out.println("Course" + i + " [" + code + "." + section + "(" + title + "), " + credits + ", "
                + faculty + ", " + advised + "/" + limit + ", " + dayTimeString() + ", " + room + ", "
                + type + "]");
    }

    private String dayTimeString() {
        if (dayTime.isEmpty()) return "\u001B[31mNull\u001B[0m";
        String dts = "";
        int i = 0;
        while (true) {
            dts += dayTime.get(i);
            if (i >= dayTime.size() - 1) return "<" + dts + ">";
            dts += "-";
            i++;
        }
    }
}
