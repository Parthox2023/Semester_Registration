import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class FileTransfer {
    ArrayList<Course> courses = new ArrayList<>();
    String[] week = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};


    public void shortingLine() {
        String sourceFile = "AdvisingTable";
        String destFile = "ShortedTable";

        try (BufferedReader br = new BufferedReader(new FileReader(sourceFile));
             BufferedWriter bw = new BufferedWriter(new FileWriter(destFile))) {

            String line;
            while ((line = br.readLine()) != null) {
                if (line.isEmpty()) continue;

                if (line.length() > 6 && line.substring(0,6).matches("^[A-Za-z]{3}\\d{3}$")) {
                    bw.newLine();
                }
                bw.write(line + ",");
            }

            System.out.println("Took all course successfully!");

        } catch (IOException e) {
            System.err.println("Error during shorting: " + e.getMessage());
        }
    }

    void fileToClass() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("ShortedTable"));
        String line = reader.readLine();
        int col;

        while ((line = reader.readLine()) != null) {
            col = 0;
            String[] row = line.split(",");
            String code = "";
            String section = "";
            String title = "";
            int credits = 0;
            String faculty = "";
            int advised = 0;
            int limit = 0;
            ArrayList<Integer> dayTime = new ArrayList<>();
            String room = "";
            String type = "";

            if (row[col].length() > 6 && row[col].substring(0,6).matches("^[A-Za-z]{3}\\d{3}$")) {
                String[] cosec = row[col++].split("\\.");
                code = cosec[0];
                section = cosec[1];
                title = row[col++];
            }

            if (row[col].matches("-?\\d+")) credits = Integer.parseInt(row[col++]);

            if (row[col].startsWith("[")) {
                col++;
                faculty = row[col++];
            }

            if (row[col].matches("-?\\d+")) advised = Integer.parseInt(row[col++]);
            if (row[col].matches("-?\\d+")) limit = Integer.parseInt(row[col++]);
            if (advised >= limit) continue;


            while (row[col].length() > 28 && row[col].charAt(4) == '#') {
                room = row[col].substring(28);
                String s = row[col].substring(0,3);
                int d, i = 0;
                while (i < week.length) {
                    if (s.equals(week[i])) break;
                    i++;
                }
                d = i*1440;
                d += Integer.parseInt(row[col].substring(6,8))*60;
                d += Integer.parseInt(row[col].substring(9,11));
                dayTime.add(d);
                d = i*1440;
                d += Integer.parseInt(row[col].substring(17,19))*60;
                d += Integer.parseInt(row[col++].substring(20,22));
                dayTime.add(d);
            }
            boolean b = false;
            for (int d : dayTime) {
                if (d / 1440 == 5 || d / 1440 == 6 || d / 1440 == 0 /*|| (d >= 1440+16*60+30 && d <= 1440+18*60)*/) {
                    b = true;
                    break;
                }
            }
            if (b) continue;

            if (row[col].charAt(0) == 'R') type = row[col];

            courses.add(new Course(code, section, title, credits, faculty, advised, limit, dayTime, room, type));
        }
    }
}
