import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        //Copy course table from ums & past it to the AdvisingTable
        FileTransfer ft = new FileTransfer();
        System.out.print("Press y to take all course: ");
        Scanner scn = new Scanner(System.in);
        if (scn.nextLine().equals("y")) ft.shortingLine();
        ft.fileToClass();

        System.out.print("Classes\tMatch\tDays\tHours\t\tCourses\n");
        SelectCourses sc = new SelectCourses(ft.courses);
        sc.selection(0);
    }
}
