import java.util.ArrayList;

public class SelectCourses {
    ArrayList<Integer> selectedIndices = new ArrayList<>();
    ArrayList<Course> courses;
    int total;

    public SelectCourses(ArrayList<Course> courses) {
        this.courses = courses;
    }

    void selection(int nextI) {
        for (int i = nextI; i < courses.toArray().length; i++) {
            if (noMatch(i)) {
                if (total + courses.get(i).credits > 14) continue;
                total += courses.get(i).credits;
                selectedIndices.add(i);
                if (total > 11) new Analyzing(courses, selectedIndices).view();
                selection(i + 1);
                total -= courses.get(i).credits;
                selectedIndices.remove(selectedIndices.size() - 1);
            }
        }
    }

    private boolean noMatch(int comparedIndex) {
        for (int i = 0; i < selectedIndices.toArray().length; i++) {
            Course course1 = courses.get(selectedIndices.get(i));
            Course course2 = courses.get(comparedIndex);

            if (course1.code.equals(course2.code)) return false;

            ArrayList<Integer> dayTime1 = course1.dayTime;
            ArrayList<Integer> dayTime2 = course2.dayTime;

            for (int j = 0, k = 0; j < dayTime1.size() &&  k < dayTime2.size(); ) {
                if (dayTime1.get(j) < dayTime2.get(k)) {
                    if (dayTime1.get(++j) > dayTime2.get(k)) {
                        return false;
                    }
                    j++;
                } else {
                    if (dayTime1.get(j) < dayTime2.get(++k)) {
                        return false;
                    }
                    k++;
                }
            }
        }
        return true;
    }
}
